import 'package:chat_app/utils/helper/Auth_helper.dart';
import 'package:chat_app/utils/helper/firebasedatabase_helper.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';

import '../../utils/helper/FCM_notification_helper.dart';

class ChatPage extends StatefulWidget {
  const ChatPage({super.key});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  @override
  Widget build(BuildContext context) {
    Map<String, dynamic> receiver =
        ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
    final TextEditingController chatcontroller = TextEditingController();
    return Scaffold(
        appBar: AppBar(
          title:
              (receiver['email'] == AuthHelper.firebaseAuth.currentUser!.email)
                  ? Text("You")
                  : Text(
                      "$receiver['email']",
                      textAlign: TextAlign.center,
                    ),
          centerTitle: true,
        ),
        body: Column(
          children: [
            Expanded(
              flex: 14,
              child: FutureBuilder(
                future: FirestoreHelper.firestoreHelper
                    .fetchMessages(receiverEmail: receiver['email']),
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return Center(
                      child: Text("ERROR: ${snapshot.error}"),
                    );
                  } else if (snapshot.hasData) {
                    Stream<QuerySnapshot<Map<String, dynamic>>>? datastram =
                        snapshot.data;

                    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                      stream: datastram,
                      builder: (context, ss) {
                        if (ss.hasError) {
                          return Center(
                            child: Text("ERROR: ${ss.error}"),
                          );
                        } else if (ss.hasData) {
                          QuerySnapshot<Map<String, dynamic>> data = ss.data!;
                          List<QueryDocumentSnapshot<Map<String, dynamic>>>
                              allMessages = data.docs;

                          return allMessages.isEmpty
                              ? Center(child: Text("No Messages..."))
                              : ListView.builder(
                                  reverse: true,
                                  itemCount: allMessages.length,
                                  itemBuilder: (context, index) {
                                    return Row(
                                      mainAxisAlignment: (receiver['email'] !=
                                              allMessages[index]
                                                  .data()['receiverEmail'])
                                          ? MainAxisAlignment.start
                                          : MainAxisAlignment.end,
                                      children: [
                                        GestureDetector(
                                          onLongPress: () async {
                                            await showMenu(
                                              context: context,
                                              position: RelativeRect.fromLTRB(
                                                  300, 550, 0, 0),
                                              items: [
                                                const PopupMenuItem(
                                                    value: 'edit',
                                                    child: Text("Edit")),
                                                const PopupMenuItem(
                                                  value: 'update',
                                                  child: Text('Update'),
                                                ),
                                                const PopupMenuItem(
                                                  value: 'delete',
                                                  child: Text('Delete'),
                                                ),
                                              ],
                                            );
                                          },
                                          child: Chip(
                                            label: Text(
                                                "${allMessages[index].data()['message']}"),
                                          ),
                                        ),
                                      ],
                                    );
                                  },
                                );
                        }
                        return Center(
                          child: CircularProgressIndicator(),
                        );
                      },
                    );
                  }
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                },
              ),
            ),
            SingleChildScrollView(
              child: Expanded(
                flex: 2,
                child: Container(
                  alignment: Alignment.center,
                  padding: const EdgeInsets.all(16),
                  child: TextField(
                    controller: chatcontroller,
                    decoration: InputDecoration(
                      hintText: "Message",
                      suffixIcon: IconButton(
                        onPressed: () async {
                          String message = chatcontroller.text;
                          String? token =
                              await FirebaseMessaging.instance.getToken();
                          await FirestoreHelper.firestoreHelper.sendMessage(
                            receiverEmail: receiver['email'],
                            message: message,
                            tokan: token!,
                          );
                          chatcontroller.clear();
                          FCMNotificationHelper.fCMNotificationHelper.sendFCM(
                              title: message,
                              body: AuthHelper.firebaseAuth.currentUser!.email!,
                              tokan: receiver['tokan']);
                        },
                        icon: Icon(Icons.send),
                      ),
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ));
  }
}
